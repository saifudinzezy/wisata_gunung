<?php 
	include '../../koneksi.php';

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$id = $_POST['id'];
		$nama = $_POST['nama'];
		$latitude = $_POST['latitude'];
		$longitude = $_POST['longitude'];
	
        //query untuk menambahkan data
		$query = "INSERT INTO pos VALUES (null, '$id', '$nama', '$latitude', '$longitude')";

		$exeQuery = mysqli_query($con, $query);

		echo ($exeQuery) ? json_encode(array('code' => 200, 'message' => 'Data berhasil disimpan')) : json_encode(array('code' => 400, 'message' => 'data gagal disimpan'));
	} else{
		echo json_encode(array('code' => 404, 'message' => 'request tidak valid'));
	}
 ?>