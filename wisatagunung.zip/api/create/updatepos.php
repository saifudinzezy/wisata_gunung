<?php 
	include '../../koneksi.php';
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$id = $_POST['id'];
		$nama = $_POST['nama'];
		$latitude = $_POST['latitude'];
		$longitude = $_POST['longitude'];

		$query = "UPDATE pos SET nama='$nama', latitude='$latitude', longitude='$longitude' WHERE id_pos='$id'";
		$exeQuery = mysqli_query($con, $query);

		echo ($exeQuery) ? json_encode(array('code' =>200, 'message' => 'data berhasil ubah')) : json_encode(array('code' =>400, 'message' => 'data gagal diubah'));
	}	else {
		echo json_encode(array('code' =>404, 'message' => 'request tidak valid'));
		}
 ?>