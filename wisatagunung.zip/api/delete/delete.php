<?php 
	include '../../koneksi.php';

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$tabel = $_POST['tabel'];
		$cari = $_POST['cari'];
		$id = $_POST['id_data'];

			$query = "DELETE FROM $tabel WHERE $cari = '$id' ";
			$exeQuery = mysqli_query($con, $query);

			echo ($exeQuery) ? json_encode(array('kode' => 1, 'pesan' => 'Data Berhasil Dihapus')) : json_encode(array('kode' => 2, 'pesan' =>'data gagal dihapus'));			
	} else {
		echo json_encode(array('kode' => 101, 'pesan' => 'request tidak valid'));
	}
 ?>