<?php

/*Jika file yang disertakan adalah satu tingkat lebih tinggi dari halaman web dengan direktif inklusi Anda dapat menggunakan:
KODE
termasuk ('../ header.php');
dan jika dua tingkat lebih tinggi:
KODE
termasuk ('../../ header.php');*/

    //koneksi
    // definisikan koneksi ke database
    include '../../koneksi.php';
    
    $sql = mysqli_query($con,"SELECT * FROM wisata ORDER BY id_wisata DESC");
    
    //untuk menampung isi data
    $response=array();
    $cek=mysqli_num_rows($sql);
    if($cek >0){
        $response["wisata"]=array();
        //$responsepos["pos"]=array();
        //buat var array yang dibutuhkan
        $responsepos=array();
        $data=array();
        $data2=array();
        //perulangan
        //ambil data dr query
        while ($row=mysqli_fetch_array($sql)){   
            //ambil value sesuai dengan nama tabel dan masukan ke array     
            $data["id_wisata"]=$row["id_wisata"];
            $data["image"]=$row["image"];
            $data["judul"]=$row["judul"];
            $data["lokasi"]=$row["lokasi"];
            $data["deskripsi"]=$row["deskripsi"];
            $data["latitude"]=$row["latitude"];
            $data["longitude"]=$row["longitude"];

            //pos pendakian
            //ambil data sesuai dengan id
            $cari = $row["id_wisata"];
            $sql2 = mysqli_query($con,"SELECT * FROM pos WHERE id_wisata = '$cari' ORDER BY id_pos DESC");
            while ($pos = mysqli_fetch_array($sql2)){
                //masukan nilai ke array
                $data2["id_pos"]=$pos["id_pos"];
                $data2["id_wisata"]=$pos["id_wisata"];
                $data2["nama"]=$pos["nama"];
                $data2["latitude"]=$pos["latitude"];
                $data2["longitude"]=$pos["longitude"];

                //push data untuk menambahkan array ke array
                array_push($responsepos,$data2);
                // print_r($pos);
                //masukan data ke array menjadi array array
                $data["pos"] = $responsepos;
                // $data["posku"] = array($data2);
            }

            $response["pesan"]="berhasil Mengambil Data";
            $response["response"]="true";    
            array_push($response["wisata"],$data);
            // array_push($response["wisata"],$responsepos);
            //print_r($row);
        }
        //mengubah data menjadi JSON
        echo json_encode($response);
        // echo json_encode($responsepos);
    }else{
        $response["pesan"]="Gagal Mengambil Data";
        $response["response"]="false";
        echo json_encode($response);
    } 

?>