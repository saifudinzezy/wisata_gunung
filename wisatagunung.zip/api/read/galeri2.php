<?php 
    include '../../koneksi.php';

    $query = "";

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        //jika id_wisata ada
        if (isset($_POST['id_wisata'])) {
            //lakukan
            $id_wisata = $_POST['id_wisata'];
            //query untuk menampilkan data
            $query = "SELECT * FROM view WHERE id_wisata = '$id_wisata' ";
        }else{
            $query = "SELECT * FROM view ORDER BY id_view DESC ";
        }    

        $exeQuery = mysqli_query($con, $query);

        $response=array();
        $cek=mysqli_num_rows($exeQuery);
        if($cek >0){
            $response["data"]=array();
            //perulangan
            while ($row=mysqli_fetch_array($exeQuery)){
                $data=array();

                $data["id_view"]=$row["id_view"];
                $data["id_wisata"]=$row["id_wisata"];
                $data["nama"]=$row["nama"];
                $data["image"]=$row["image"];
                
                $response["pesan"]="berhasil Mengambil Data";
                $response["response"]="true";    

                array_push($response["data"],$data);
                // print_r($row);
            }
            //mengubah data menjadi JSON
            echo json_encode($response);
        }else{
            $response["pesan"]="Gagal Mengambil Data";
            $response["response"]="false";
            echo json_encode($response);
        } 
    } else{
        echo json_encode(array('kode' => 101, 'pesan' => 'request tidak valid'));
    }
 ?>