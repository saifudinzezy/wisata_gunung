<?php

/*Jika file yang disertakan adalah satu tingkat lebih tinggi dari halaman web dengan direktif inklusi Anda dapat menggunakan:
KODE
termasuk ('../ header.php');
dan jika dua tingkat lebih tinggi:
KODE
termasuk ('../../ header.php');*/

    //koneksi
    // definisikan koneksi ke database
    include '../../koneksi.php';
    
    $sql = mysqli_query($con,"SELECT * FROM manfaat t1 INNER JOIN  admin t2 ON t1.id_admin = t2.id_admin ORDER BY id_manfaat DESC"); 
    
    //query untuk menampilkan semua data ditable
    // $sql=mysqli_query($con,"SELECT * FROM jadwal_tranfusi ORDER BY id_tranfusi desc");
    //untuk menampung isi data
    $response=array();
    $cek=mysqli_num_rows($sql);
    if($cek >0){
        $response["manfaat"]=array();
        //perulangan
        while ($row=mysqli_fetch_array($sql)){
            $data=array();
            $data["id_manfaat"]=$row["id_manfaat"];
            $data["id_admin"]=$row["id_admin"];
            $data["image"]=$row["image"];
            $data["judul"]= utf8_encode($row["judul"]);
            $data["deskripsi"]= utf8_encode($row["deskripsi"]);
            $data["tanggal"]=$row["tanggal"];
            $data["nama"]=$row["nama"];        
            
            $response["pesan"]="berhasil Mengambil Data";
            $response["response"]="true";    
            array_push($response["manfaat"],$data);
            // print_r($row);
        }
        //mengubah data menjadi JSON
        echo json_encode($response);
    }else{
        $response["pesan"]="Gagal Mengambil Data";
        $response["response"]="false";
        echo json_encode($response);
    } 

?>