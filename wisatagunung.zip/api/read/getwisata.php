<?php

/*Jika file yang disertakan adalah satu tingkat lebih tinggi dari halaman web dengan direktif inklusi Anda dapat menggunakan:
KODE
termasuk ('../ header.php');
dan jika dua tingkat lebih tinggi:
KODE
termasuk ('../../ header.php');*/

    //koneksi
    // definisikan koneksi ke database
    include '../../koneksi.php';
    
    $sql = mysqli_query($con,"SELECT * FROM wisata ORDER BY id_wisata DESC"); 
    
    //query untuk menampilkan semua data ditable
    // $sql=mysqli_query($con,"SELECT * FROM jadwal_tranfusi ORDER BY id_tranfusi desc");
    //untuk menampung isi data
    $response=array();
    $cek=mysqli_num_rows($sql);
    if($cek >0){
        $response["wisata"]=array();
        //perulangan
        while ($row=mysqli_fetch_array($sql)){
            $data=array();
            $data["id_wisata"]=$row["id_wisata"];
            $data["image"]=$row["image"];
            $data["judul"]= utf8_encode($row["judul"]);
            $data["lokasi"]=$row["lokasi"];
            $data["deskripsi"]= utf8_encode($row["deskripsi"]);
            $data["latitude"]=$row["latitude"];
            $data["longitude"]=$row["longitude"];
            $data["ketinggian"]=$row["ketinggian"];
            $data["fasilitas"]=$row["fasilitas"];
            $data["tipe_tanah"]=$row["tipe_tanah"];
            $data["tipe_gunung"]=$row["tipe_gunung"];
            
            $response["pesan"]="berhasil Mengambil Data";
            $response["response"]="true";    
            array_push($response["wisata"],$data);
            // print_r($row);
        }
        //mengubah data menjadi JSON
        echo json_encode($response);
    }else{
        $response["pesan"]="Gagal Mengambil Data";
        $response["response"]="false";
        echo json_encode($response);
    } 

?>