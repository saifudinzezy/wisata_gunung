<?php 
    include '../../koneksi.php';

    //jadwal tranfusi and kelasi besi

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $id_wisata = $_POST['id_wisata'];
        
        //query untuk menambahkan data
        $query = "SELECT * FROM pos WHERE id_wisata = '$id_wisata' ";

        $exeQuery = mysqli_query($con, $query);

        $response=array();
        $cek=mysqli_num_rows($exeQuery);
        if($cek >0){
            $response["pos_pendakian"]=array();
            //perulangan
            while ($row=mysqli_fetch_array($exeQuery)){
                $data=array();

                $data["id_pos"]=$row["id_pos"];
                $data["id_wisata"]=$row["id_wisata"];
                $data["nama"]=$row["nama"];
                $data["latitude"]=$row["latitude"];
                $data["longitude"]=$row["longitude"];
                $data["pos"]=$cek;
                
                $response["pesan"]="berhasil Mengambil Data";
                $response["response"]="true";    

                array_push($response["pos_pendakian"],$data);
                // print_r($row);
            }
            //mengubah data menjadi JSON
            echo json_encode($response);
        }else{
            $response["pesan"]="Gagal Mengambil Data";
            $response["response"]="false";
            echo json_encode($response);
        } 
    } else{
        echo json_encode(array('kode' => 101, 'pesan' => 'request tidak valid'));
    }
 ?>